#!/usr/bin/env python

from lib import stashclient
from lib.config import projectkey
import csv

projecturl = "rest/api/1.0/projects/" + projectkey + "/permissions/users"

users = stashclient.execute_request(projecturl)
usernames_permission = {}
usernames_name = {}

with open('stash-users.csv', "wb") as csv_file:
    writer = csv.writer(csv_file, delimiter=',')
    header = ['DISPLAY NAME', 'USERNAME', 'EMAIL ADDRESS', 'IS ACTIVE', 'PERMISSION']
    writer.writerow(header)

    for user in users:

        email=''
        if 'emailAddress' in user['user']: email=user['user']['emailAddress']
        username=user['user']['name']
        permission=user['permission']
        isactive=user['user']['active']
        displayname=user['user']['displayName']
        namearray = displayname.split(',')

        if len(namearray) > 1:
            displayname = namearray[1].rstrip().lstrip() + " " + namearray[0].rstrip().lstrip()
        else:
            displayname = namearray[0]

        row = [displayname, username, email, isactive, permission]
        writer.writerow(row)
