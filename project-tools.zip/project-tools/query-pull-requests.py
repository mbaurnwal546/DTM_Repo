#!/usr/bin/env python
# -*- coding: interpy -*-


def get_pull_requests(repository, state="ALL", order="NEWEST", at=None, project="REAL"):
    from lib import api

    baseuri = "rest/api/1.0/projects/#{project}/repos"
    endpoint = "#{baseuri}/#{repository}/pull-requests"
    data = {"state": state, "order": order}
    if at is not None: data["at"] = at

    return api.request(endpoint, params=data)


def print_pull_request_summaries(pull_requests):
    for value in pull_requests['values']:
        summary = ( """#{value.get('id')} #{value.get('state')}.\n\
                    #{value.get('fromRef').get('id')} => #{value.get('toRef').get('id')} \n\
                    by #{value.get('author').get('user').get('displayName')}. \n\
                    value.get('link').get('url') \n""")
        print summary


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', required=True)
    parser.add_argument('--branch', required=False, default="")
    parser.add_argument('--state', required=False, default="ALL")
    parser.add_argument('--order', required=False, default="NEWEST")
    parser.add_argument('--project', required=False, default="REAL")
    args = parser.parse_args()

    requests = get_pull_requests(repository=args.repository,
                                 state=args.state,
                                 order=args.order,
                                 at="refs/heads/" + args.branch,
                                 project=args.project)

    print_pull_request_summaries(requests)
