#!/usr/bin/env python

import json
import sys
import urllib2
from lib import api

with open('projects.json') as projectsfile:
    projects = json.load(projectsfile)

repourl = "rest/branch-utils/latest/projects/%s/repos/%s/branches"
tagurl = "rest/git/1.0/projects/%s/repos/%s/tags"
commiturl = "rest/api/1.0/projects/%s/repos/%s/commits"
pullrequesturl = "rest/api/1.0/projects/%s/repos/%s/pull-requests"

def arguments_error_message():
    print("Please provide required command line arguments in following syntax")
    print("List of actions that can be executed:")
    print("create_branch")
    print("create_pullrequest")
    print("create_tag" + "  [Creates tag on head commit of specified branch]")
    print("create_release_tag" + "  [Creates tag on head commit of master branch]")
    print("Commands: ")
    print("./version-control-actions.py create_branch <new_branch_name> <source_branch>")
    print("./version-control-actions.py create_tag <ref_branch_name> <tag_name>")
    print("./version-control-actions.py create_release_tag <release_name> <tag_name>")
    print("./version-control-actions.py create_pullrequest <from_branch> <to_branch>")
    exit(1)

def validate_input_parse_arguments():
    global action
    global newbranch
    global parentbranch
    global sourcebranch
    global refbranch
    global releasename
    global tagname
    global tagdescription

    if len(sys.argv) != 4:
        arguments_error_message()
    valid_actions=['create_branch','create_tag','create_release_tag','create_pullrequest']
    action = sys.argv[1]

    if not action in valid_actions:
        arguments_error_message()

    if action == 'create_branch':
        newbranch = sys.argv[2]
        parentbranch = sys.argv[3]
    elif action == 'create_tag':
        refbranch = sys.argv[2]
        tagname = sys.argv[3]
    elif action == 'create_pullrequest':
        refbranch = sys.argv[2]
        sourcebranch = sys.argv[3]
    elif action == 'create_release_tag':
        refbranch = 'master'
        if sys.argv[2].startswith('release/'):
            releasename = sys.argv[2]
        else:
            releasename = "release/" + sys.argv[2]
        tagname = sys.argv[3]

def get_request_body_create_pullrequest(project, repo):
    title = "Merge request from " + refbranch + " to " + sourcebranch
    data = {
        "title": title,
        "description": None,
        "state": "OPEN",
        "open": True,
        "closed": False,
        "fromRef": {
            "id": refbranch,
            "repository": {
                "slug": repo,
                "name": None,
                "project": {
                    "key": project
                }
            }
        },
        "toRef": {
            "id": sourcebranch,
            "repository": {
                "slug": repo,
                "name": None,
                "project": {
                    "key": project
                }
            }
        },
        "reviewers": []
    }
    return data

def get_request_body_create_branch(branchname, parentbranch):
    data = {
        'name': branchname,
        'startPoint': parentbranch
    }
    return data

def get_request_body_create_tag():
    branchname = "refs/heads/" + refbranch
    data = {
        'force': 'true',
        'message': tagname,
        'name': tagname,
        'startPoint': branchname,
        'type': 'ANNOTATED'
    }
    return data

def create_pull_request(project, repo):
    url = pullrequesturl % (project, repo)
    data = get_request_body_create_pullrequest(project, repo)
    method = 'POST'
    return api.request(url, data, method)

def create_tag(project, repo):
    url = tagurl % (project, repo)
    data = get_request_body_create_tag()
    method = 'POST'
    api.request(url, data, method)

def validate_branches_in_sync(project, repo, branchone, branchtwo):
    url = commiturl % (project, repo)
    data = {'until': branchone}
    branchoneheadcommit = api.request(url, params=data)['values'][0]['id']
    data = {'until': branchtwo}
    branchtwoheadcommit = api.request(url, params=data)['values'][0]['id']
    return branchoneheadcommit == branchtwoheadcommit

def create_branch():
    data = get_request_body_create_branch(newbranch, parentbranch)
    method = 'POST'
    print("Creating " + newbranch + " from " + parentbranch)
    for project in projects['projects']:
        for repo in projects['projects'][project]:
            url = repourl % (project, repo)
            print("Project: " + project + " Repo: " + repo)
            api.request(url, data, method)
    print("Success..!! Created new branches for all the repositories listed in projects.json")

def create_release_tag():
    print("Creating tag " + tagname + " from head commit of master branch")
    for project in projects['projects']:
        for repo in projects['projects'][project]:
            print("Project: " + project + " Repo: " + repo)
            if validate_branches_in_sync(project, repo, releasename, 'master'):
                create_tag(project, repo)
            else:
                print("Failed to create release tag for Project: " + project + " Repo: " + repo)
                print("Please merge " + releasename + " and master branch before creating release tags.")
    print("Success..!! Created tags for for all the repositories listed in projects.json")

def create_generic_tag():
    print("Creating tag " + tagname + " from head commit of " + refbranch +" branch")
    for project in projects['projects']:
        for repo in projects['projects'][project]:
            print("Project: " + project + " Repo: " + repo)
            create_tag(project, repo)
    print("Success..!! Created tags for all the repositories listed in projects.json")

def create_generic_pull_request():
    print("Creating pull requests from " + refbranch + " to " + sourcebranch + " for all specified projects")
    for project in projects['projects']:
        for repo in projects['projects'][project]:
            if validate_branches_in_sync(project, repo, refbranch, sourcebranch):
                print("Project: " + project + " Repo: " + repo + " PR not needed branches in sync")
            else:
                try:
                    response = create_pull_request(project, repo)
                    print("Project: " + project + " Repo: " + repo + " PR url : " + response['links']['self'][0]['href'])
                except urllib2.HTTPError as err:
                    if err.code == 409:
                        print("Project: " + project + " Repo: " + repo + " Open PR already exists between " + refbranch + " and " + sourcebranch)
                    else:
                        print("Failed to create PR for Project: " + project + " Repo: " + repo )
                        raise

def execute_action():
    if action == 'create_branch':
        create_branch()
    elif action == 'create_tag':
        create_generic_tag()
    elif action == 'create_release_tag':
        create_release_tag()
    elif action == 'create_pullrequest':
        create_generic_pull_request()

validate_input_parse_arguments()
execute_action()