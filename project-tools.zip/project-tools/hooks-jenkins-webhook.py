#!/usr/bin/env python

from lib import api


jenkinsTarget = "http://jenkins-u.realizedev-test.com/jenkins"
sshBaseUrl = "ssh://git@bitbucket.pearson.com/real"
httpBaseUrl = "https://serv.realole.builder@bitbucket.pearson.com/scm/real"
plugin = "com.atlassian.stash.plugin.stash-web-post-receive-hooks-plugin"


def set_webhooks_for_all_projects():
    method = 'PUT'

    for project in api.repos.get("REAL").get('slugs'):
        print 'Enabling commit webhook for ', project
        endpoint = "rest/api/latest/projects/REAL/repos/%s/settings/hooks/%s:postReceiveHook/enabled" % (
            project,
            plugin
        )

        data = {
            "hook-url-0": "%s/git/notifyCommit?url=%s/%s.git" % (
                jenkinsTarget,
                sshBaseUrl,
                project
            ),
            "hook-url-1": "%s/git/notifyCommit?url=%s/%s.git" % (
                jenkinsTarget,
                httpBaseUrl,
                project
            )
        }

        try:
            print api.request(endpoint, data, method)
        except Exception, e:
            print e


set_webhooks_for_all_projects()
