#!/usr/bin/env python
# -*- coding: interpy -*-

from lib import api
from lib import browser

import atexit
import inquirer

def set_branching_model(details, project_key):
    stash = browser.Stash()
    stash.login()
    atexit.register(stash.logout, True)
    for slug in details.get('projects'):
        print "Setting Branching Model for project: " + slug
        driver = stash.go("plugins/servlet/branchmodel/projects/#{project_key}/repos/#{slug}")

        for model in ['development', 'production']:
            element = stash.hidden(model.upper())
            element.clear()
            element.send_keys(details.get(model))

        for prefix in ['bugfix', 'feature', 'hotfix', 'release']:
            element = stash.hidden("#{prefix.upper()}-prefix")
            element.clear()
            element.send_keys(details.get(prefix))

        automerge = driver.find_element_by_id('auto-merge')
        needsCheck = automerge.is_selected() and not details.get('automerge')
        needsUncheck = not automerge.is_selected() and details.get('automerge')
        if needsCheck or needsUncheck: automerge.click()

        driver.find_element_by_id('branch-model-settings-form-submit').submit()

answers = inquirer.prompt([
    inquirer.Checkbox('projects',
        message='Which projects should be affected?',
        choices=api.repos.keys(),
        default=["REAL"],
        validate=lambda _, choices: (len(choices) > 0) )
])

for project_key in answers.get('projects'):
    print("Setting branching model for '{}'".format(project_key))
    repos = api.repos.get(project_key)
    questions = [
        inquirer.Checkbox('repositories',
            message='Which repositories should be affected?',
            choices=repos.get('slugs')),

        inquirer.Text('development', message='development branch?', default='develop'),
        inquirer.Text('production', message='production branch?', default='master'),
        inquirer.Text('bugfix', message='bugfix prefix?', default='bugfix/'),
        inquirer.Text('feature', message='feature prefix?', default='feature/'),
        inquirer.Text('hotfix', message='hotfix prefix?', default='hotfix/'),
        inquirer.Text('release', message='release prefix?', default='release/'),
        inquirer.Confirm('automerge', message='Enable automatic merge?', default=True),

        inquirer.Confirm('done', message='Are the responses above correct?', default=True)
    ]

    answers = dict(done=False)
    while not answers.get('done'):
        answers = inquirer.prompt(questions)

    set_branching_model(answers, project_key);
