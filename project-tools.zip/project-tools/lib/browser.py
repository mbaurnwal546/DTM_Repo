# -*- coding: interpy -*-

import api
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

class Stash(object):
    def __init__(self):
        super(Stash, self).__init__()
        self.driver = webdriver.Chrome()

    def login(self):
        self.logout()
        self.go('login')
        self.driver.find_element_by_id('j_username').send_keys(api.username)
        self.driver.find_element_by_id('j_password').send_keys(api.password)
        self.driver.find_element_by_id('submit').submit()

    def go(self, path):
        self.driver.get("#{api.baseurl}/#{path}")
        return self.driver

    def hidden(self, elID):
        self.driver.execute_script("document.getElementById('#{elID}').setAttribute('type', 'text')")
        self.driver.execute_script("document.getElementById('#{elID}').classList.remove('hidden')")
        return self.driver.find_element_by_id(elID)

    def logout(self, andClose=False):
        self.go("j_stash_security_logout")
        if andClose: self.driver.close()
