# -*- coding: interpy -*-

from config import baseurl, project_configs

import urllib2
import urllib
import json
import base64
import getpass

username = None
password = None

def authorize_request(request):
    global username, password

    if username is None: username = raw_input("username: ")
    if password is None: password = getpass.getpass()
    if len(username) == 0 or len(password) == 0:
        print "[ERROR] 'username' or 'password' not valid"
        sys.exit(1)
    base64string = base64.encodestring("#{username}:#{password}").replace('\n', '')
    request.add_header('Authorization', "Basic #{base64string}")

def request(endpoint, data=None, method='GET', params=None):
    method = method.upper()

    query = urllib.urlencode(params) if params is not None else ""
    request = urllib2.Request("#{baseurl}/#{endpoint}?#{query}")
    request.add_header('Content-Type', 'application/json')
    authorize_request(request)

    if data is not None: data = json.dumps(data)
    if method == 'PUT': request.get_method = lambda: 'PUT'

    # debug line:
    # print "\n#{request.get_method()} #{request.get_full_url()}\nbody:#{request.get_data()}"

    response = urllib2.urlopen(request, data).read()
    if response == '' :
        return None
    return json.loads(response)

def paged_request(*args, **kwargs):
    pagedresults = [];
    response = request(*args, **kwargs)
    pagedresults = pagedresults + response.get('values')
    while not bool(response.get('isLastPage', True)):
        params = kwargs.get('params', dict())
        params['start'] = response['nextPageStart']
        kwargs['params'] = params
        response = request(*args, **kwargs)
        pagedresults = pagedresults + response.get('values')
    return pagedresults

projects = {}
for project_key in project_configs.keys():
    projects[project_key] = paged_request("rest/api/1.0/projects/#{project_key}/repos")

repos = {}
for project_key, raw_repos in projects.iteritems():
    repos[project_key] = dict(
        urls=[ repo['links']['self'] for repo in raw_repos ],
        slugs=[ repo['slug'] for repo in raw_repos ])
