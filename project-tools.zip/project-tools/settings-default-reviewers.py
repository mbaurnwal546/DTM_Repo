#!/usr/bin/env python
# -*- coding: interpy -*-

from lib import api
from lib.api import projects
from lib.config import project_configs

import inquirer
import sys

def get_request_body(branchName, defaultUsers, refType="BRANCH"):
    fullUsers = []
    users = set(defaultUsers)
    for user in users:
        if user.lower() not in globalUsers :
            userReqParams = {"avatarSize": 32, "start": 0, "filter": user.lower()}

            userResponse = api.request("/".join(["rest/api/latest/users"]), None, 'GET', userReqParams)
            values = userResponse.get('values')
            if len(values) > 0 :
                firstUser = values[0]
            else :
                print 'no user found with user_id: ', user.lower()
        else :
            firstUser = globalUsers[user.lower()]

        fullUsers.append(firstUser)
        globalUsers[user.lower()] = firstUser

    data = {
        'projectKey': "#{project_key}",
        'users': fullUsers,
        'groups': [],
        'refName': branchName,
    }

    if refType.upper() == 'BRANCH':
        data['refName'] = branchName,
    elif refType.upper() == 'PATTERN':
        data['refPattern'] = branchName
    return data

def check_for_reviewers_id(repositorySlug, branchRef):
    endpoint = "/".join([apiendpoint, repositorySlug])
    response = api.request(endpoint)
    for value in response['values']:
        if value['value'] == branchRef:
            return value['id']
    return None

def set_reviewers(repositorySlug, branchName, defaultUsers, refType=None):
    branchName = "refs/heads/%s" % branchName
    method = 'POST'
    endpoint = '/'.join([apiendpoint, repositorySlug])
    data = get_request_body(branchName, defaultUsers, refType)
    data['repoSlug'] = repositorySlug
    api.request(endpoint, data, method)


def set_reviewers_for_all_projects(projects, branchName, defaultUsers, refType='pattern'):
    print("Setting the following users as default reviewers:")
    print(", ".join(defaultUsers))
    for project in projects:
        print 'Starting repository: ' + project + ' and branch: ' + branch
        try:
            set_reviewers(
                repositorySlug=project,
                branchName=branchName,
                defaultUsers=defaultUsers,
                refType=refType)
            print 'Completed project: ' + project + ' and branch: ' + branch
        except Exception, e:
            print 'Failed to set reviewers for', project
            print e, e.read()

globalUsers = {}
answers = inquirer.prompt([
    inquirer.Checkbox('projects',
        message='Which projects should be affected?',
        choices=api.repos.keys(),
        default=[],
        validate=lambda _, choices: (len(choices) > 0) )
])

for project_key in answers.get('projects'):
    repos = api.repos.get(project_key)
    apiendpoint = "rest/workzoneresource/latest/branch/reviewers/#{project_key}"
    project_config = project_configs.get(project_key)

    all_repos = list(repos.get('slugs'))
    non_default_repos = project_config.get('non-default-repos')
    # all_repos - non_default_repos
    default_repos = [repo for repo in all_repos if repo not in non_default_repos ] if non_default_repos != None else all_repos

    default_groups = project_config.get('groups').keys()
    if project_key == 'REAL':
        default_groups.remove('sqe leads')
        default_groups.remove('release engineers')

    print("Setting default reviewers for '{}'".format(project_key))
    questions = [
        inquirer.Checkbox('projects',
            message='Which repositories should be affected?',
            choices=repos.get('slugs'),
            default=default_repos,
            validate=lambda _, choices: (len(choices) > 0) ),

        inquirer.Checkbox('branches',
            message='Which branches should be affected?',
            choices=['master', 'develop', 'release/*', 'hotfix/*', 'bugfix/*', 'feature/*'],
            default=['master', 'develop', 'release/*', 'hotfix/*'],
            validate=lambda _, choices: (len(choices) > 0) ),

        inquirer.Checkbox('groups',
            message='Which groups should be affected?',
            choices=project_config.get('groups').keys(),
            default=default_groups,
            validate=lambda _, choices: (len(choices) > 0) )
    ]

    answers = inquirer.prompt(questions)

    try:
        for branch in answers.get('branches'):
            users = []
            for group in answers.get('groups'):
                for user in project_config.get('groups').get(group):
                    users.append(user)

            set_reviewers_for_all_projects(
                projects=answers.get('projects'),
                branchName=branch,
                defaultUsers=users
            )
    except Exception, e:
        print e
