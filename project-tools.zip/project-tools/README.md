# Stash Project Tools

A set of commands for effectively managing repositories of a Stash project.

## Set up

Before using these tools, you need to install the requirements listed in 
_requirements.txt_ at the root of this project. Try running `make install` 
on the project. If this doesn't work, you may need to manually install `pip` 
and run

    pip install -r requirements.txt --user

* * * 

## branch permissions

run `./branch-permissions.py` to set the branch permissions for one or more projects.


## branching model

run `./branching-model.py` to set the branching model for one or more projects. 

The [Branch Utils REST API][] provides only read access to the branch model, so 
we use selenium to accomplish this.

## pull requests

run `./query-pull-requests.py` to get information about pull request for a project.

This method accepts a set of options. `./query-pull-requests --help` for 
more info.

## default reviewers

run `./setting-default-reviewers.py`

## jenkins webhook

**WIP**

* * * 

# Issues

1.  This project uses a library called [inquirer][] to collect command line input.
    When prompting for projects, this presents an issue as the number of projects 
    can be exceedingly long. When this happens, keying up and down to select projects 
    becomes ineffective.

    One workaround is to increase the vertical height of the Terminal window as well 
    as decrease the font size (e.g. [Cmd -] on Mac) until the list of projects is 
    almost entirely in view.
2.  The list of projects is request dynamically every time a command is executed.
    This is slow and may quickly become annoying to the user

[inquirer]: https://github.com/magmax/python-inquirer
[Branch Utils REST API]: https://developer.atlassian.com/static/rest/stash/3.9.2/stash-branch-utils-rest.html#idp74176