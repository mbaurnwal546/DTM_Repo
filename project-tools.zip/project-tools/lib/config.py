import json

with open('config.json') as projectconfigfile:
    info = json.load(projectconfigfile)

baseurl = info.get('base_url')
project_configs = info.get('projects')
