#!/usr/bin/env python
# -*- coding: interpy -*-

from lib import api
from lib.api import projects
from lib.config import project_configs

import inquirer
import sys

def get_request_body(branchName, allowedUsers, permissionType="BRANCH"):
    data = {
        'type': 'read-only',
        'matcher': {
            'id': branchName,
            'displayId': branchName,
            'type': {
                'id': permissionType,
                'name': permissionType
            },
            'active': 'true'

        },
        'value': branchName,
        'users': allowedUsers,
        'groups': []
    }
    return data


def check_for_permission_id(repositorySlug, branchRef):
    endpoint = "/".join([apiendpoint, repositorySlug, 'restrictions'])
    response = api.request(endpoint)
    for value in response['values']:
        displayId = value['matcher']['displayId']
        if branchRef.endswith(displayId):
            return value['id']
    return None


def set_permissions(repositorySlug, branchName, allowedUsers, permId=None, permissionType=None):
    print "Setting Branch Permissions for project: " + repositorySlug + " and branch name: " + branchName
    branchName = "refs/heads/#{branchName}"
    method = 'POST'
    endpoint = '/'.join([apiendpoint, repositorySlug, 'restrictions'])
    data = get_request_body(branchName, allowedUsers, permissionType)

    if permId is None: permId = check_for_permission_id(repositorySlug, branchName)

    if permId is not None:
        method = 'POST'
        #endpoint = "%s/%s" % (endpoint, permId)
        data['id'] = permId
    return api.request(endpoint, data, method)


def set_permissions_for_projects(projects, branchName, allowedUsers, permId=None, permissionType=None):
    if sys.version_info >= (3,0):
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=15) as executor:
            # https://docs.python.org/3.3/library/concurrent.futures.html#threadpoolexecutor-example

            future_to_project = { executor.submit(set_permissions, repositorySlug=project, branchName=branchName, allowedUsers=allowedUsers, permId=permId, permissionType=permissionType): project for project in projects }

            for future in concurrent.futures.as_completed(future_to_project):
                project = future_to_project[future]
                try:
                    data = future.result()
                except Exception as e:
                    print 'Failed to set permissions for', project
                    print e, e.read()
    else:
        for project in projects:
            try:
                set_permissions(repositorySlug=project, branchName=branchName, allowedUsers=allowedUsers, permId=permId, permissionType=permissionType)
            except Exception, e:
                print 'Failed to set permissions for', project
                print e, e.read()


answers = inquirer.prompt([
    inquirer.Checkbox('projects',
        message='Which projects should be affected?',
        choices=api.repos.keys(),
        default=[],
        validate=lambda _, choices: (len(choices) > 0) )
])

for project_key in answers.get('projects'):
    print("Updating branch permissions for project '{}'".format(project_key))
    repos = api.repos.get(project_key)
    apiendpoint = "rest/branch-permissions/2.0/projects/#{project_key}/repos"
    project_config = project_configs.get(project_key)

    default_repos=list(repos.get('slugs'))
    default_groups=project_config.get('groups').keys()
    if project_key == 'REAL':
        default_repos.remove('aws-devops-s')
        default_repos.remove('online-learning-exchange-config')
        default_repos.remove('ui-tests')
        default_repos.remove('project-tools')
        default_groups.remove('default reviewers')
        default_groups.remove('sqe leads')

    questions = [
        inquirer.Checkbox('repositories',
            message='Which repositories should be affected?',
            choices=repos.get('slugs'),
            default=default_repos,
            validate=lambda _, choices: (len(choices) > 0) ),

        inquirer.Checkbox('branches',
            message='Which branches should be affected?',
            choices=['master', 'develop', 'release/*'],
            default=['develop'],
            validate=lambda _, choices: (len(choices) > 0) ),

        inquirer.Checkbox('groups',
            message='Which groups should be affected?',
            choices=project_config.get('groups').keys(),
            default=default_groups,
            validate=lambda _, choices: (len(choices) > 0) )
    ]

    answers = inquirer.prompt(questions)

    for branch in answers.get('branches'):
        users = []
        for group in answers.get('groups'):
            for user in project_config.get('groups').get(group):
                users.append(user)

        set_permissions_for_projects(
            projects=answers.get('repositories'),
            branchName=branch,
            allowedUsers=users,
            permissionType='PATTERN' if '*' in branch else 'BRANCH')
